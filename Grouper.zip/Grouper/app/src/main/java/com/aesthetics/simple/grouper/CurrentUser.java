package com.aesthetics.simple.grouper;

import com.aesthetics.simple.grouper.com.simpleaesthetics.application.Model.Group;

/**
 * Created by visha on 2017-10-31.
 */

public class CurrentUser {
    public static String username = "Vishahan";
    public static String currentGroup = "Simple Aesthetics";
}
